import React from "react";

const Group = props => {
  return (
    <div>

    </div>
  );
};

Group.propTypes = {
  
};

export default Group;