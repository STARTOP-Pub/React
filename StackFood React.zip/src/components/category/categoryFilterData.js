export const mockData = [
    {
        id: 0,
        name: 'Veg',
        value: 'veg',
    },
    {
        id: 1,
        name: 'Non Veg',
        value: 'non_veg',
    },
    {
        id: 2,
        name: 'Top rated',
        value: 'top_rated',
    },
    {
        id: 3,
        name: 'Newly Joined',
        value: 'latest',
    },

]
