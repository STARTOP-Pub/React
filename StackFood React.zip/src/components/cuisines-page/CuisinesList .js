import React from 'react';

const CuisinesList  = () => {
    return (
        <div>
            CuisinesList
        </div>
    );
};

export default CuisinesList ;
