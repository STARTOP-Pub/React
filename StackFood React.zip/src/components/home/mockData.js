export const mockData = [
    {
        id: 0,
        category_name: 'All',
        value: 'all',
    },
    {
        id: 1,
        category_name: 'Newly Joined',
        value: 'latest',
    },
    {
        id: 2,
        category_name: 'Delivery',
        value: 'delivery',
    },
    {
        id: 3,
        category_name: 'Take Away',
        value: 'take_away',
    },
    {
        id: 4,
        category_name: 'Dine In',
        value: 'dine_in',
    },
    {
        id: 5,
        category_name: 'Popular',
        value: 'popular',
    },
]
