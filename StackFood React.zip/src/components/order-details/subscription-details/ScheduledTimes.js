import React from 'react';

const ScheduledTimes = props => {

    return (
        <div>

        </div>
    );
};

ScheduledTimes.propTypes = {

};

export default ScheduledTimes;