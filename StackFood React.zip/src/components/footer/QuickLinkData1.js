export const QuickLinkData1 = [
    {
        name: 'New Restaurants',
        value: 'latest',
        link: '/restaurant/latest',
    },
    {
        name: 'Popular Restaurants',
        value: 'popular',
        link: '/restaurant/popular',
    },
    {
        name: 'Best Reviewed Foods',
        value: 'most-reviewed',
        link: '/products/best-reviewed-foods',
    },
    {
        name: 'Track Order',
        value: 'track_order',
        link: '/tracking',
    },
]
