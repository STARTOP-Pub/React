export const QuickLinkData = [
    {
        name: 'About Us',
        value: 'about Us',
        link: '/about-us',
    },
    {
        name: 'My Wallet',
        value: 'wallets',
        link: '/customer/wallets',
    },
    {
        name: 'Loyalty Points',
        value: 'loyalty',
        link: '/customer/loyality',
    },
    {
        name: 'Cuisines',
        value: 'cuisines',
        link: '/cuisines',
    }
]
