export const OtherData = [
    {
        name: 'Privacy Policy',
        value: 'privacy-policy',
        link: '/privacy-policy',
    },
    {
        name: 'Term & Conditions',
        value: 'term-&-Conditions',
        link: '/terms-and-conditions',
    },
    // {
    //     name: 'Refund Policy',
    //     value: 'refund-policy',
    //     link: '/refund-policy',
    // },
    // {
    //     name: 'Cancellation Policy',
    //     value: 'cancellation-policy',
    //     link: '/cancellation-policy',
    // },
    // {
    //     name: 'Shipping Policy',
    //     value: 'shipping-policy',
    //     link: '/shipping-policy',
    // },
]
