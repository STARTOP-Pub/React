import React from 'react'
import CheckoutPage from './CheckoutPage'

const CheckOut = ({ isDineIn }) => {
    return (
        <>
            <CheckoutPage isDineIn={isDineIn} />
        </>
    )
}

export default CheckOut
