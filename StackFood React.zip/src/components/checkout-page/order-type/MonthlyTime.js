import React from 'react';

const MonthlyTime = () => {
    return (
        <div>
            MonthlyTime
        </div>
    );
};

export default MonthlyTime;