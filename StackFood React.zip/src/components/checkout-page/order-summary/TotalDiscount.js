import React from 'react'

const TotalDiscount = (props) => {
    const { cartList, restaurantData } = props
    // const { data } = restaurantData

    return <div></div>
}

TotalDiscount.propTypes = {}

export default TotalDiscount
