export const productUnavailableData = [
    'Remove it form my cart',
    'I will wait until it is restocked',
    'Please cancel the order',
    'Call me ASAP',
    'Notify me when it is back',
]
export const deliveryInstructions = [
    'Deliver to the front door',
    'Deliver to the reception desk',
    'Avoid calling phone',
    'Come with no sound',
]
